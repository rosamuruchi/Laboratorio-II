using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.Xml;

namespace ENTIDADES.SP
{
  public delegate void EventoPrecio(string s, double d); //Creo delegado

  public class Cajon <T> : ISerializar<T>
  {
    protected int _capacidad;
    protected List<T> _elementos;
    protected double _precioUnitario;

    public event EventoPrecio MuyCaro; //Creo evento

    public List<T> Elementos
    {
      get
      {
        return this._elementos;
      }
    }

    public double PrecioTotal
    {
      get
      {
        return this._precioUnitario * this._elementos.Count;
      }
    }

    public Cajon()
    {
      this._elementos = new List<T>();
    }

    public Cajon(int capacidad) : this()
    {
      this._capacidad = capacidad;
    }

    public Cajon(double precio, int capacidad) : this(capacidad)
    {
      this._precioUnitario = precio;
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendFormat("Capacidad: {0}\n", this._capacidad);
      sb.AppendFormat("Cantidad total: {0}\n" ,this._elementos.Count);
      sb.AppendLine("Elementos: ");

      foreach (T item in this._elementos)
      {
        sb.AppendLine(item.ToString());
      }

      return sb.ToString();
    }

    public static Cajon<T> operator +(Cajon<T> cajon, T item)
    {
      try
      {
        if (cajon._elementos.Count < cajon._capacidad)
        {
          cajon._elementos.Add(item);

          if (cajon.PrecioTotal > 55)
          {
            cajon.MuyCaro("cajonCaro.txt", cajon.PrecioTotal);
            MessageBox.Show("El cajón superó los $55, gastando $" + cajon.PrecioTotal + " se generó un archivo .txt");
          }
        }
        else
        {
          throw new CajonLlenoException();
        }
      }
      catch (Exception)
      {

      }

      return cajon;
    }

    public bool Xml(string path)
    {
      bool retorno = false;
      string direccion = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + path;
      try
      {
        XmlSerializer serializer = new XmlSerializer(typeof(Cajon<T>));
        XmlTextWriter writer = new XmlTextWriter(direccion, Encoding.UTF8);
        serializer.Serialize(writer, this);
        writer.Close();
        retorno = true;

      }
      catch (Exception)
      {
        retorno = false;
      }

      return retorno;
    }
    
  }
}
