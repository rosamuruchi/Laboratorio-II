using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES.SP
{
  public class Banana : Fruta
  {
    protected string _paisOrigen;

    public override bool TieneCarozo
    {
      get
      {
        return false;
      }
    }

    public string Nombre
    {
      get
      {
        return "Banana";
      }
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();

      sb.Append(base.FrutaToString());
      sb.AppendFormat("Pais: {0}",this._paisOrigen);

      return sb.ToString();
    }

    public Banana(string nombre, double peso, string pais) : base(nombre, peso)
    {
      this._paisOrigen = pais;
    }
  }
}
