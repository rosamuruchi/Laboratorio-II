using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ENTIDADES.SP
{
  public class Manejadora
  {
    public void PrecioCaro(string path, double precio)
    {
      string direccion = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + path;
      try
      {
        using (StreamWriter sw  = new StreamWriter(direccion, true))
        {
          sw.WriteLine("Precio total: {0}", precio);
          sw.WriteLine(DateTime.Now);
          sw.Close();
        }
      }
      catch (Exception)
      {

      }
    }
  }
}
