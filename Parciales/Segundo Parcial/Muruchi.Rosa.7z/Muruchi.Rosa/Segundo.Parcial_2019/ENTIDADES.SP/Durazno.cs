using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES.SP
{
  public class Durazno:Fruta
  {
    protected int _cantPelusa;

    public override bool TieneCarozo
    {
      get
      {
        return true;
      }
    }

    public string Nombre
    {
      get
      {
        return "Durazno";
      }
    }

    public Durazno(string nombre, double peso, int pelusa) : base(nombre, peso)
    {
      this._cantPelusa = pelusa;
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();

      sb.Append(base.FrutaToString());
      sb.AppendLine("Cantidad pelusa: " + this._cantPelusa);

      return sb.ToString();
    }

    
  }
}
